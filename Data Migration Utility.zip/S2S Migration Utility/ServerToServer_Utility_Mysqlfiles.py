import json
import sys
import math
import csv 
from datetime import timedelta  
from datetime import datetime 
import pymysql as my
import pandas as pd
import os,re, glob, shutil
from concurrent import futures
from queue import Queue
import subprocess
import threading
import psycopg2
#import paramiko
#import pysftp
from fabric import Connection
from mysql.connector import MySQLConnection, Error


class S2S_Migration_Utility_Mysqlfiles():

    def Read_Configuration(self , FileName):
        
        '''
        Module parsing the given json config file to read the Mysql different connection credentials 
        and lookup tables information.
        '''
        
        if not os.path.isfile(os.getcwd()+"\\"+FileName):
            return False , FileName +' file does not exist at ' +os.getcwd() + '\\'
        
        JsonFile = open(FileName).read()
        
        try:
            self.config_dict = json.loads(JsonFile)
        except ValueError as e:
            
            return False, FileName +': Decoding JSON has failed \nInformation: ' + str(e)
        
        return True , ''  

 
    def Load_Data_CSV(self,df_Chunk):
        f = open("Logfile.txt", "a")
        try:
            #Set Credentials and basic Connection Settings-------------------------------
            
            mysqlconn = MySQLConnection(**self.arch_config)
            mysqlcursor = mysqlconn.cursor()
        
            #----------------------------------------------------------------------------
            
            x = df_Chunk
            now = datetime.now()
            
            #Set Filename from Source Global Variable
            Filename = self.mysql_table.replace('.','_')
            query = "select * from "+self.mysql_schema+".`"+self.mysql_table+"` \n limit "+str(self.limit) +" offset "+str(x*self.limit)+";"
            
            results = pd.read_sql_query(query, mysqlconn)
             
            
            #If First File then Add headers, if not then dont add headers
            #File will be String enclosed, Comma Separated and no Index
            results.to_csv(self.filepath+self.mysql_table.replace('.','_')+"//"+Filename+'_'+str(x)+'.csv',sep="~",na_rep='qwerty$$qwerty',header=False,escapechar='\\',doublequote = True, quoting = 1,index = False, line_terminator="\n")
            
            now = datetime.now()
            f.write(str(datetime.now())+" [Info]: File has been created with name: "+str(Filename))   
        except ValueError as e:
            print('--------------------Error Occurred in process ---------------------- \n'+ str(e))   
            f.write(str(datetime.now())+" [Error]: Exception occurred in process \n "+str(e)+"\n")   
        f.close()
    
    def RunUtil_mysqlfiles(self,Config_FileName):

        Status = False
        Return_Arg="Before Start"
        f = open("Logfile.txt", "a")
        try:
            ######### Reading JSON Config ################
            Status , Return_Arg = self.Read_Configuration(Config_FileName)
            print(Return_Arg)
            self.arch_config = self.config_dict['DBCredentials']['arch']
            self.mysql_schema = self.config_dict['GpfDist_Config']['MysqlSchema']                    #Source Name
            self.mysql_table = self.config_dict['GpfDist_Config']['MYSQLTable_name']                     #Source Table Name in MYSQL
            self.filepath = self.config_dict['GpfDist_Config']['FilePath']                        #Filepath where the CSV and Zip will be created
            self.total_size = self.config_dict['GpfDist_Config']['Total_Count']                      #Total Expected Size
            self.limit = self.config_dict['GpfDist_Config']['File_Count_limit']                           #Chunk Size
            
            foldername = self.mysql_table.replace('.','_')
            isdir = os.path.isdir(self.filepath+foldername+"//")
            
            f.write(str(datetime.now())+" [Info]: Process has been started for table "+self.mysql_table+"using GPFDist \n")
            
            if isdir == False:
                
                os.mkdir(self.filepath+foldername)
                os.mkdir(self.filepath+foldername+"_Processed")
                No_Of_Chunks = math.ceil(self.total_size/self.limit)                                        #Calculate No of Chunks
                print("Number of files to be created: "+str(No_Of_Chunks))
                chunk_list = list(range(int(No_Of_Chunks)))   
                chunks = pd.DataFrame(chunk_list,columns=['Chunk'])
                f.write(str(datetime.now())+" [Info]: Files Creation Process has been started \n")
                with futures.ThreadPoolExecutor() as executor:
                    results = futures.wait([executor.submit(self.Load_Data_CSV,Chunk) for Chunk in range(int(No_Of_Chunks))])
                
                    for result in results.done:
                        if result.exception() is not None:
                            raise result.exception()
                print("Files has been created")    
                f.write(str(datetime.now())+" [Info]: All files has been created \n")
            else:
                print("######## Table Folder Already Exists - Resuming Remaining Files ########")   
        except ValueError as e:
            print('--------------------Error Occurred in process ---------------------- \n'+ str(e))   
            f.write(str(datetime.now())+" [Error]: Exception occurred in process \n "+str(e)+"\n")
        
        f.close()
        return Status , Return_Arg
            


    
    
