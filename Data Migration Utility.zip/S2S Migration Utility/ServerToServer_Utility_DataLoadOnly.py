# -*- coding: utf-8 -*-
"""
Created on Tue Apr 12 08:33:56 2022

@author: PAM_DA_BLUE
"""

# -*- coding: utf-8 -*-
"""
Created on Thu Mar 24 07:27:39 2022

@author: pam-de
"""

import json
import sys
import math
from datetime import datetime  
from datetime import timedelta  
import pymysql as my
import pandas as pd
import os,re, glob, shutil
from queue import Queue
import subprocess
import threading
import psycopg2
#import paramiko
#import pysftp
from fabric import Connection
from mysql.connector import MySQLConnection, Error
import re


class S2S_Migration_Utility_DataLoadOnly():

    def Read_Configuration(self , FileName):
        
        '''
        Module parsing the given json config file to read the Mysql different connection credentials 
        and lookup tables information.
        '''
        
        if not os.path.isfile(os.getcwd()+"\\"+FileName):
            return False , FileName +' file does not exist at ' +os.getcwd() + '\\'
        
        JsonFile = open(FileName).read()
        
        try:
            self.config_dict = json.loads(JsonFile)
        except ValueError as e:
            
            return False, FileName +': Decoding JSON has failed \nInformation: ' + str(e)
        
        return True , ''  

    
    
    def RunUtil(self,Config_FileName):

        Status = False
        

        Return_Arg="Before Start"
        
        f = open("Logfile.txt", "a")
        try:
            ######### Reading JSON Config ################
            Status , Return_Arg = self.Read_Configuration(Config_FileName)
            
            
            table= self.config_dict['PxfReader_Config']['MYSQLTable_name']
            view_name= self.config_dict['PxfReader_Config']['MysqlView_name']
            gptablename= self.config_dict['PxfReader_Config']['GPFinalTable_name']
            external_table= self.config_dict['PxfReader_Config']['GPExtTable_name']
            mysqlschema= self.config_dict['PxfReader_Config']['MysqlSchema']
            mysqldevschema= self.config_dict['PxfReader_Config']['MysqlDevSchema']
            gpschema = self.config_dict['PxfReader_Config']['GpSchema']
            mysqltogpcon = self.config_dict['PxfReader_Config']['MysqltoGpCon']
            interval = self.config_dict['PxfReader_Config']['Interval']
            mindate = self.config_dict['PxfReader_Config']['MinDate']
            maxdate = self.config_dict['PxfReader_Config']['MaxDate']
            datecolumn = self.config_dict['PxfReader_Config']['DateColumn']
            encoding = self.config_dict['PxfReader_Config']['Encoding']
            poolsize = self.config_dict['PxfReader_Config']['Pool_size']
            batchsize = self.config_dict['PxfReader_Config']['Batch_size']
            distributioncolumn = self.config_dict['PxfReader_Config']['DistributionColumn']
            
            if gptablename=="":
                gptablename= table.replace('.','_')

            if poolsize != 0:
                pool = "POOL_SIZE="+str(poolsize)
            else:
                pool= ""
            
            chunknum = 0
            f.write(str(datetime.now())+" [Info]: Process has been started for table "+table+"using PXF Reader \n")
            
            ######## Creating mysql connection ##########
            arch_config = self.config_dict['DBCredentials']['arch']
            mysqlconn = MySQLConnection(**arch_config)
            mysqlcursor = mysqlconn.cursor()
            
            if external_table == "":           
                external_table= "ext_r_"+ table.replace(".","_")
                
            if view_name == "":    
                view_name = "vw_"+ table.replace(".","_")
				
			               
            ######## Creating GP connection ##########
            gp_connfig = self.config_dict['DBCredentials']['gp']
            conn = psycopg2.connect(**gp_connfig)
            cur = conn.cursor()
            
            
            regexp = re.compile('[^0-9a-zA-Z\_]+')
            ######## Getting Create Statement of Mysql Table ##########
          
            information_schema_statement ="SELECT Column_name, Data_type, character_maximum_length,column_default,is_nullable,1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '"+gpschema+"' AND TABLE_NAME = '"+external_table+"' ;"
            
            cur.execute(information_schema_statement)
            column_name = []
            column_name_view = []
            columns= []
            datatypes = []
            length = []
            column_default = []
            nullable = []
            column_key = []
            records = cur.fetchall()
            for row in records:
                if regexp.search(row[0]):
                    column_name.append('"'+row[0]+'"')
                    column_name_view.append('"'+row[0]+'"')
                    
                else:
                    column_name.append(row[0])
                    column_name_view.append(row[0])
                
                columns.append(row[0])
                datatypes.append(row[1])
                length.append(row[2])
                column_default.append(row[3])
                nullable.append(row[4])
                column_key.append(row[5])
            
                       
            
            ######## Checking if Final Table exists / Retreiving failed chunk start date #########
            check_table_statement = "select case when exists (select * from "+mysqldevschema+".s2s_logtable where tablename='"+table+"') then 1 else 0 end as tbl_check"
            mysqlcursor.execute(check_table_statement)
            f.write(str(datetime.now())+" [Info]: Checking if Table has been already exists or not \n")
            records = mysqlcursor.fetchall()
            for x in records:
                table_status = x[0]
            
            
            
            
 
            
            
            ######## Reading Data Type Mappings File ##########
            datatypeDict = {}
            with open("DataType_Mappings.txt") as myfile:
                for line in myfile:
                    name, var = line.partition("=")[::2]
                    datatypeDict[name.strip()] = var
                    
            
            
           ######## Create Final Table Command ##########
            final_table = gptablename
            if table_status == 0:
                print("Table doesn't exist. Use Method 1 if you want it to be created.")
            else:
                print("Table already exists, resuming table from where it failed"+"\n")
                f.write(str(datetime.now())+" [Info]: Table already exists, resuming table from where it failed"+"\n")
                get_failedchunk_statement = "select chunk_startdate, chunk_enddate, status, chunkid from "+mysqldevschema+".s2s_logtable where chunkid = (select max(chunkid) as id from "+mysqldevschema+".s2s_logtable where tablename = '"+table+"' ) order by status desc limit 1;"
                mysqlcursor.execute(get_failedchunk_statement)
                records = mysqlcursor.fetchall()
                var_status =""
                var_chunk_startdate=""
                var_chunk_enddate=""
                var_chunkid=""
                for x in records:
                    var_chunk_startdate = x[0]
                    var_chunk_enddate = x[1]
                    var_status = x[2]
                    var_chunkid = x[3]
                    
                if var_status == 0:
                    mindate = str(var_chunk_startdate)
                    chunknum = var_chunkid
                    delete_chunk_statement = "delete from "+gpschema+"."+final_table+" where "+datecolumn+">='"+mindate+"';"
                    cur.execute(delete_chunk_statement)
                    conn.commit()
                    f.write(str(datetime.now())+" [Info]: Last failed Chunk data has been deleted from : "+ str(mindate) + " Completed at "+ str(datetime.now())+"\n")
                elif var_status == 1 and var_chunk_enddate <  datetime.strptime(maxdate, '%Y-%m-%d').date():
                    mindate = str(var_chunk_enddate)
                    chunknum = var_chunkid+1
                else:
                    print("*********** All data has been already processed for this table *********** \n")
                    f.write(str(datetime.now())+" [Stop]: All data has been already processed for this table \n")
                    #sys.exit()       
            


            ############# Create Mysql Views using Chunking #################
            
            mysqlcursor.close()
            mysqlconn.close()
            start_date = mindate
            start_date = datetime.strptime(start_date, '%Y-%m-%d')
            maxdate = datetime.strptime(maxdate, '%Y-%m-%d')
            if interval!=0:
                f.write(str(datetime.now())+" [Info]: Chunking process has been started \n")
                print("######### Processing Data in Multiple Chunks #########")
                while start_date <= maxdate:
                                   
                    mysqlconn = MySQLConnection(**arch_config)
                    mysqlcursor = mysqlconn.cursor()                   
                    
                    ########### Insert to GP Final Table from External Table #########################
                    insert_statement = "insert into "+gpschema+"."+final_table+" ( "
                    for x in range(len(column_name_view)):
                        insert_statement = insert_statement + column_name_view[x]  + ","
                    insert_statement = insert_statement[0:-1] +" ) \n select "
                    for x in range(len(column_name_view)):
                        insert_statement = insert_statement + column_name_view[x]  + ","
                    insert_statement = insert_statement[0:-1] + " from "+gpschema+"."+external_table+ " \n where "+ datecolumn+" >= '"+str(start_date) +"' and "+ datecolumn+" < ('"+ str(start_date) +"'::date + interval '"+str(interval) + " day')" + ";"
                    f.write(str(datetime.now())+" [Info]: Insertion Started at : " + str(datetime.now())+"\n")
                    f.write(insert_statement+"\n")
					
					

                    try:
	
                        ######## Creating GP connection ##########
                        gp_connfig = self.config_dict['DBCredentials']['gp']
                        conn = psycopg2.connect(**gp_connfig)
                        cur = conn.cursor()
                        t1= datetime.now()
                        cur.execute(insert_statement)
                        conn.commit()
                        
                        print("Data Chunk from : "+ str(start_date) + " to: "+ str(start_date + timedelta(days=interval))+" Completed at "+ str(datetime.now()))
                        f.write(str(datetime.now())+" [Info]: Data Chunk from : "+ str(start_date) + " to: "+ str(start_date + timedelta(days=interval))+" Completed at "+ str(datetime.now())+"\n")
                        t2= datetime.now()
                        
                        mysqlcursor.close()
                        mysqlconn.close()
                        
                        insert_chunk_statement = "insert into "+mysqldevschema+".s2s_logtable (`tablename`,`chunkid`,`chunk_startdate`,`chunk_enddate`,`status`,`process_time_sec`) values ('"+table+"',"+str(chunknum)+",'"+str(start_date)+"','"+str(start_date + timedelta(days=interval))+"',1,'"+str(t2-t1)+"');"
                        
                        mysqlconn = MySQLConnection(**arch_config)
                        mysqlcursor = mysqlconn.cursor()
                        
                        mysqlcursor.execute(insert_chunk_statement)
                        mysqlconn.commit()
                        f.write(str(datetime.now())+" [Info]: Data chunk log entry has been inserted \n")
                        mysqlcursor.close()
                        mysqlconn.close()
                    except Exception as e:
                        mysqlconn = MySQLConnection(**arch_config)
                        mysqlcursor = mysqlconn.cursor()
                        insert_chunk_statement = "insert into "+mysqldevschema+".s2s_logtable (`tablename`,`chunkid`,`chunk_startdate`,`chunk_enddate`,`status`,`process_time_sec`) values ('"+table+"',"+str(chunknum)+",'"+str(start_date)+"','"+str(start_date + timedelta(days=interval))+"',0,'0');"
                        #print(insert_chunk_statement);
                        print('--------------------Error Occurred in process, please see the logs file for more details ')   
                        f.write(str(datetime.now())+" [Error]: Exception occurred in process \n "+str(e)+"\n")
                        mysqlcursor.execute(insert_chunk_statement)
                        mysqlconn.commit()
                        
                        mysqlcursor.close()
                        mysqlconn.close()
                        exit()
                    
                    start_date= start_date + timedelta(days=interval)
                    chunknum=chunknum+1
                    
                f.write(str(datetime.now())+" [Info]: All data has been transferred \n ")
                print("All data has been transferred \n")
                f.write(str(datetime.now())+" [Info]: Verifying counts of source and final table \n ")
                print("Verifying counts of source and final table \n")
                
                mysqlconn = MySQLConnection(**arch_config)
                mysqlcursor = mysqlconn.cursor()
                mysqlcursor.execute("select count(*) from "+mysqlschema+".`"+table+"`")
                results = mysqlcursor.fetchall()
                for x in results:
                    mysqltablecount = x[0]
                print("MYSQL Table Count: "+ str(mysqltablecount)+"\n")
                mysqlcursor.close()
                mysqlconn.close()
                gp_connfig = self.config_dict['DBCredentials']['gp']
                conn = psycopg2.connect(**gp_connfig)
                cur = conn.cursor()
                cur.execute("select count(*) from "+gpschema+"."+final_table)
                results_gp = cur.fetchall()
                for x in results_gp:
                    gptablecount = x[0]
                print("GP Table Count: "+ str(gptablecount)+"\n")
                if mysqltablecount==gptablecount:
                    print("Counts has been matched from source to final table \n")
                else:
                    print("Counts are not matching from source to final table, please check your data manually")
				
                
            else:

                mysqlconn = MySQLConnection(**arch_config)
                mysqlcursor = mysqlconn.cursor()
                
               
                insert_statement = "insert into "+gpschema+"."+final_table+" ( "
                for x in range(len(column_name_view)):
                    insert_statement = insert_statement + column_name_view[x]  + ","
                
                insert_statement = insert_statement[0:-1] +" ) \n select "
                for x in range(len(column_name_view)):
                    insert_statement = insert_statement + column_name_view[x]  + ","
                
                insert_statement = insert_statement[0:-1] + " from "+gpschema+"."+external_table+";"
                f.write(insert_statement+"\n")
                f.write(str(datetime.now())+" [Info]: Insertion Started at : " + str(datetime.now())+"\n")
                try:
                    t1= datetime.now()
                    cur.execute(insert_statement)
                    conn.commit()
                    print("Insertion Ended at : " + str(datetime.now()))
                    f.write(str(datetime.now())+" [Info]: Insertion Ended at : " + str(datetime.now()))
                    t2= datetime.now()
                    
                    mysqlcursor.close()
                    mysqlconn.close()
                    
                    insert_chunk_statement = "insert into "+mysqldevschema+".s2s_logtable (`tablename`,`chunkid`,`chunk_startdate`,`chunk_enddate`,`status`,`process_time_sec`) values ('"+table+"',"+str(chunknum)+",'"+str(start_date)+"','"+str(maxdate)+"',1,'"+str(t2-t1)+"');"
                    
                    mysqlconn = MySQLConnection(**arch_config)
                    mysqlcursor = mysqlconn.cursor()
                    
                    mysqlcursor.execute(insert_chunk_statement)
                    
                    mysqlconn.commit()
                    f.write(str(datetime.now())+" [Info]: Data log entry has been inserted \n")
                    mysqlcursor.close()
                    mysqlconn.close()
                    
                    f.write(str(datetime.now())+" [Info]: All data has been transferred \n ")
                    print("All data has been transferred \n")
                    f.write(str(datetime.now())+" [Info]: Verifying counts of source and final table \n ")
                    print("Verifying counts of source and final table \n")
                    
                    mysqlconn = MySQLConnection(**arch_config)
                    mysqlcursor = mysqlconn.cursor()
                    mysqlcursor.execute("select count(*) from "+mysqlschema+".`"+table+"`")
                    
                    results = mysqlcursor.fetchall()
                    for x in results:
                        mysqltablecount = x[0]
                    print("MYSQL Table Count: "+ str(mysqltablecount)+"\n")
                    mysqlcursor.close()
                    mysqlconn.close()
                    gp_connfig = self.config_dict['DBCredentials']['gp']
                    conn = psycopg2.connect(**gp_connfig)
                    cur = conn.cursor()
                    cur.execute("select count(*) from "+gpschema+"."+final_table)
                    results_gp = cur.fetchall()
                    for x in results_gp:
                        gptablecount = x[0]
                    print("GP Table Count: "+ str(gptablecount)+"\n")
                    if mysqltablecount==gptablecount:
                        print("Counts has been matched from source to final table \n")
                    else:
                        print("Counts are not matching from source to final table, please check your data manually")
                    
                    
                except Exception as e:
                    mysqlconn = MySQLConnection(**arch_config)
                    mysqlcursor = mysqlconn.cursor()
                    insert_chunk_statement = "insert into "+mysqldevschema+".s2s_logtable (`tablename`,`chunkid`,`chunk_startdate`,`chunk_enddate`,`status`,`process_time_sec`) values ('"+table+"',"+str(chunknum)+",'"+str(start_date)+"','"+str(maxdate)+"',0,'0');"
                    print('--------------------Error Occurred in process, please see the logs file for more details ')   
                    f.write(str(datetime.now())+" [Error]: Exception occurred in process \n "+str(e)+"\n")
            
                    mysqlcursor.execute(insert_chunk_statement)   
                    mysqlconn.commit()
                    
                    mysqlcursor.close()
                    mysqlconn.close()
        except ValueError as e:
            print('--------------------Error Occurred in process ---------------------- \n'+ str(e))   
            f.write(str(datetime.now())+" [Error]: Exception occurred in process \n "+str(e)+"\n")   
        f.close()
         
        return Status , Return_Arg
            


    
    
