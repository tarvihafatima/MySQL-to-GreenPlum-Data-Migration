import json
import sys
import time
import math
from datetime import datetime  
from datetime import timedelta  
import pymysql as my
import pandas as pd
import os,os.path,re, glob, shutil
from queue import Queue
import subprocess
import threading
import psycopg2
import shutil
#import paramiko
#import pysftp
from fabric import Connection
from mysql.connector import MySQLConnection, Error
import subprocess
import time


class S2S_Migration_Utility_GpfDist():

    def Read_Configuration(self , FileName):
        
        '''
        Module parsing the given json config file to read the Mysql different connection credentials 
        and lookup tables information.
        '''
        
        if not os.path.isfile(os.getcwd()+"\\"+FileName):
            return False , FileName +' file does not exist at ' +os.getcwd() + '\\'
        
        JsonFile = open(FileName).read()
        
        try:
            self.config_dict = json.loads(JsonFile)
        except ValueError as e:
            
            return False, FileName +': Decoding JSON has failed \nInformation: ' + str(e)
        
        return True , ''
        
        
    def RunUtil_GpfDist(self,Config_FileName):
        Status = False       
        Return_Arg="Before Start"
        
        f = open("Logfile.txt", "a")
        try:
            ######### Reading JSON Config ################
            Status , Return_Arg = self.Read_Configuration(Config_FileName)
            
            table= self.config_dict['GpfDist_Config']['MYSQLTable_name']
            gptablename= self.config_dict['GpfDist_Config']['GPFinalTable_name']
            devboxip = self.config_dict['GpfDist_Config']['DevBoxIP']
            port = self.config_dict['GpfDist_Config']['Port']
            filepath =  self.config_dict['GpfDist_Config']['FilePath']
            filepath = filepath + table.replace('.','_') + "//"
            processedfile= self.config_dict['GpfDist_Config']['FilePath'] + table.replace('.','_') + "_Processed//"
            encoding = self.config_dict['GpfDist_Config']['Encoding']

            
            mysqlschema= self.config_dict['GpfDist_Config']['MysqlSchema']
            mysqldevschema= self.config_dict['GpfDist_Config']['MysqlDevSchema']        
            gpschema = self.config_dict['GpfDist_Config']['GpSchema']
            print("GPFdist process has been started \n")
            f.write(str(datetime.now())+" [Info]: Files Creation Process has been started \n")
            ######### Running GPFDist in Background #########
            gpfdist = 'gpfdist -d ' + filepath + ' -p ' + port + ' -m 655350'
            os.system('start cmd /k '+gpfdist)
            time.sleep(10)
            print("GPFDist command has been executed in backgroup")
            f.write(str(datetime.now())+" [Info]: GPFDist command has been executed in backgroup \n "+gpfdist+"\n")
            
            if gptablename=="":
                gptablename= table.replace('.','_')
            
            
            ######## Creating mysql connection ##########
            arch_config = self.config_dict['DBCredentials']['arch']
            mysqlconn = MySQLConnection(**arch_config)
            mysqlcursor = mysqlconn.cursor()
            
            information_schema_statement ="SELECT Column_name, Data_type, character_maximum_length,column_default,is_nullable, column_key FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '"+mysqlschema+"' AND TABLE_NAME = '"+table+"' ;"
            regexp = re.compile('[^0-9a-zA-Z\_]+')
            mysqlcursor.execute(information_schema_statement)
            column_name = []
            column_name_view = []
            columns= []
            datatypes = []
            length = []
            column_default = []
            nullable = []
            column_key = []
            records = mysqlcursor.fetchall()
            for row in records:
                if regexp.search(row[0]):
                    column_name.append('"'+row[0]+'"')
                    column_name_view.append('"'+row[0]+'_mapped"')
                    
                else:
                    column_name.append(row[0])
                    column_name_view.append(row[0]+'_mapped')
                
                columns.append(row[0])
                datatypes.append(row[1])
                length.append(row[2])
                column_default.append(row[3])
                nullable.append(row[4])
                column_key.append(row[5])
            
             ######## Creating GP connection ##########
            gp_connfig = self.config_dict['DBCredentials']['gp']
            conn = psycopg2.connect(**gp_connfig)
            cur = conn.cursor()
            
            ######## Reading Data Type Mappings File ##########
            datatypeDict = {}
            with open("DataType_Mappings.txt") as myfile:
                for line in myfile:
                    name, var = line.partition("=")[::2]
                    datatypeDict[name.strip()] = var
            datatypeDict1 = {}
            with open("DataType_Mappings_gpf.txt") as myfile1:
                for line1 in myfile1:
                    name1, var1 = line1.partition("=")[::2]
                    datatypeDict1[name1.strip()] = var1           
            
            
            ####### Create Final Table Command ##########
            final_table = gptablename
            gp_final_create_statement =  "drop table if exists "+gpschema+"."+final_table+"; \n create table "+gpschema+"."+final_table+" ("
            primary_key_constraint = "";
            for x in range(len(column_name)):
                if length[x] is not None and (datatypes[x].lower() != "text" and datatypes[x].lower() != "mediumtext" and datatypes[x].lower() != "longtext") :
                    length[x] = "(" + str(length[x]) + ")"
                else:
                    length[x] = ""
                    
                if re.search("0000", str(column_default[x])) and (datatypes[x].lower() == "datetime" or datatypes[x].lower() == "timestamp" or datatypes[x].lower() == "time"):
                    column_default[x]  = "0001-01-01 01:01:01"
                    
                if column_default[x] == "00:00:00":
                   column_default[x]  = "01:01:01"
                   
                matched = re.match(".*[0-9][0-9]:[0-9][0-9]:[0-9][0-9]", str(column_default[x]))

                is_match = bool(matched)
                    
                if column_default[x] is not None and (datatypes[x].lower() == "datetime" or datatypes[x].lower() == "timestamp" or datatypes[x].lower() == "time") and is_match == False:
                       column_default[x] = str(column_default[x])
                elif (datatypes[x].lower() == "datetime" or datatypes[x].lower() == "timestamp" or datatypes[x].lower() == "time") and is_match == True:
                   column_default[x] = "'" + str(column_default[x]) + "'"
                elif column_default[x] is not None and (datatypes[x].lower() != "datetime" and datatypes[x].lower() != "timestamp" and datatypes[x].lower() != "time"):
                   column_default[x] = "'" + str(column_default[x]) + "'"
                else:
                   column_default[x] = str(column_default[x]).replace("None","NULL")
                   
                   
                gp_final_create_statement = gp_final_create_statement + column_name[x] +" "+datatypeDict[datatypes[x]] + length[x]+" "
                

                if  nullable[x].lower() == "no" and column_key[x].lower() == "pri":
                    gp_final_create_statement = gp_final_create_statement+" NOT NULL,"
                        
                elif nullable[x].lower() == "no" and column_key[x].lower() != "pri":
                    gp_final_create_statement = gp_final_create_statement+" NOT NULL DEFAULT "+column_default[x]+","
                    
                else:
                    gp_final_create_statement = gp_final_create_statement + " DEFAULT " +column_default[x]+","               
                
                if column_key[x].lower() == "pri" :
                    primary_key_constraint = primary_key_constraint+column_name[x]+",";
                        

                gp_final_create_statement = gp_final_create_statement.replace("\n","").replace(",",",\n")
                
            if len(primary_key_constraint)>1:
                primary_key_constraint = primary_key_constraint[0:-1]
                primary_key_constraint = ",\nCONSTRAINT pk_"+final_table+" PRIMARY KEY ("+primary_key_constraint+") "
                
            gp_final_create_statement = gp_final_create_statement[0:-2] + primary_key_constraint + "\n )"
            
            f.write(str(datetime.now())+" [Info]: Final Table Create Statement \n"+gp_final_create_statement+"\n")
                
            cur.execute(gp_final_create_statement)
            conn.commit()
            f.write(str(datetime.now())+" [Info]: Final Table has been created with name: "+ final_table+"\n")
            print("Final Table has been created with name: "+ final_table+"\n")
            
            ######## Reading Number of files in a folder ##################
            
            
            files = os.listdir(filepath)
            if str(files) !="[]":
                
                f.write(str(datetime.now())+" [Info]: Final processing loop begins \n")
                
                for filename in files:
                    f.write(str(datetime.now())+" [Info]: Processing file: "+filename+"\n")
                
                    ######## Creating External Table Command ############
                    external_table= "ext_"+ table.replace(".","_")+"_gpfdist"
                    gp_ext_create_statement =  "drop external table if exists "+gpschema+"."+external_table+"; \n create external table "+gpschema+"."+external_table+" ("
                
                    for x in range(len(column_name_view)):
                        gp_ext_create_statement = gp_ext_create_statement + column_name_view[x] +" text ,"
                    
                    gp_ext_create_statement = gp_ext_create_statement[0:-1] + ") \n"  + "LOCATION ( 'gpfdist://"+devboxip+":"+port+"/"+filename+"') ON ALL \n FORMAT 'CSV' (delimiter '~' escape '\\') \n ENCODING '"+encoding+"';"
                    
                    f.write(str(datetime.now())+" [Info]: External Table Statement : "+gp_ext_create_statement+"\n")

                    #print(gp_ext_create_statement+"\n")
                    cur.execute(gp_ext_create_statement)
                    conn.commit()
                    f.write(str(datetime.now())+" [Info]: External Table has been created with name: "+ external_table+ " for file: "+filename+"\n")
                    print("External Table has been created for file: "+filename+"\n")
                    
                               
                    insert_statement = "insert into "+gpschema+"."+final_table+" \n select "
                    for x in range(len(column_name_view)):
                    
                        insert_statement = insert_statement + "(case when " + column_name_view[x] + " = 'qwerty$$qwerty' then NULL else " + column_name_view[x] + " end) ::"+ datatypeDict1[datatypes[x]] +length[x]+" "+ ","
                        
                        
                    insert_statement = insert_statement[0:-1] + " from "+gpschema+"."+external_table+";"
                    #print(insert_statement+"\n")
                    cur.execute(insert_statement)
                    conn.commit()
                    f.write(str(datetime.now())+" [Info]: Insert Statement : "+insert_statement+"\n")
                    f.write(str(datetime.now())+" [Info]: Insertion has been completed for file: "+filename+"\n")
                    
                    f.write(str(datetime.now())+" [Info]: Moving file: "+filename+" to processed folder\n")
                    shutil.move(filepath+filename, processedfile+filename)
                    
                f.write(str(datetime.now())+" [Info]: All data has been transferred \n ")
                print("\n All data has been transferred \n")
                f.write(str(datetime.now())+" [Info]: Verifying counts of source and final table \n ")
                print("########## Verifying counts of source and final table ########## \n")
                
                mysqlconn = MySQLConnection(**arch_config)
                mysqlcursor = mysqlconn.cursor()
                mysqlcursor.execute("select count(*) from "+mysqlschema+".`"+table+"`")
                results = mysqlcursor.fetchall()
                for x in results:
                    mysqltablecount = x[0]
                print("MYSQL Table Count: "+ str(mysqltablecount)+"\n")
                mysqlcursor.close()
                mysqlconn.close()
                gp_connfig = self.config_dict['DBCredentials']['gp']
                conn = psycopg2.connect(**gp_connfig)
                cur = conn.cursor()
                cur.execute("select count(*) from "+gpschema+"."+final_table)
                results_gp = cur.fetchall()
                for x in results_gp:
                    gptablecount = x[0]
                print("GP Table Count: "+ str(gptablecount)+"\n")
                if mysqltablecount==gptablecount:
                    print("Counts has been matched from source to final table \n")
                else:
                    print("Counts are not matching from source to final table, please check your data manually")
            else:
                print("All files has been already processed, please delete a table folder name to retransfer this table")

        except ValueError as e:
            print('--------------------Error Occurred in process ---------------------- \n'+ str(e))   
            f.write(str(datetime.now())+" [Error]: Exception occurred in process \n "+str(e)+"\n")
        f.close()
        return Status , Return_Arg
        