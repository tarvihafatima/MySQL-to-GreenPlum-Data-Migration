import sys
import ServerToServer_Utility_GPFDist
import ServerToServer_Utility_Mysqlfiles
import ServerToServer_Utility
import ServerToServer_Utility_DataLoadOnly


var = input("Enter 1 to Create Table and Load Data Using PXF Reader \nEnter 2 to Load Data Using GPFDist \n Enter 3 to Load Data without Table Creation Using PXF Reader \n" )

if var == "1":
    print("################## Starting Process Using PXF Reader ##################")   
    p = ServerToServer_Utility.S2S_Migration_Utility()
    Status , Return_Arg = p.RunUtil("configs.json")
    print("################## Process Ended Using PXF Reader ##################")   


elif var == "2":
    print("################## Starting Process Using GPFDist ##################")   
	#p = ServerToServer_Utility_Mysqlfiles.S2S_Migration_Utility_Mysqlfiles()
    #Status , Return_Arg = p.RunUtil_mysqlfiles("configs.json")

    p1 = ServerToServer_Utility_GPFDist.S2S_Migration_Utility_GpfDist()
    Status , Return_Arg = p1.RunUtil_GpfDist("configs.json")
    print("################## Process Ended Using GPFDist ##################") 
    
elif var == "3":
    print("################## Starting Process Using PXF Reader ##################")   
    p = ServerToServer_Utility_DataLoadOnly.S2S_Migration_Utility_DataLoadOnly()
    Status , Return_Arg = p.RunUtil("configs.json")
    print("################## Process Ended Using PXF Reader ##################")   


else:
    print("################## Please Enter Valid Input ##################")   


